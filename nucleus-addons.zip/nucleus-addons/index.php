<?php
/**
 * Silence is golden
 */