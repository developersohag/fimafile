=== Nucleus Addons ===
Contributors: nucleusteam
Donate link: www.freelancersohag.com
Tags: nucleus addons, elementor, nucleus nucleus, nucleus nucleus member widget, nucleus widget
Requires at least: 6.0
Tested up to: 6.4.3
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

<ul>
  <li>Name Field</li>
  <li>Designation Field</li>
  <li>Social Media Field/li>
</ul>

== Description ==

nucleus nucleus Widget is an elementor add-on to showcase your nucleus Widget style/design. This is an simple and flexible way to add new elements/widgets.

Note: This plugin is a widget of Elementor Page Builder and will only work with Elementor Page Builder installed.

== Frequently Asked Questions ==

= Can I use the plugin without Elementor Page Builder? =

No. You cannot use without Elementor since it’s an addon for Elementor.

= Does it work with any theme? =

Absolutely! It will work with any theme where Elementor works.

= Is there any shortcode to use it in a page or post ? =

No.

== Screenshots ==

1. Nucleus Addons

== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.

= 0.5 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

= 0.5 =
This version fixes a security related bug.  Upgrade immediately.